==================================================
  PDF Splitter Pro v1.0
  PDF Smart Split & Rename Tool
==================================================

[How to Start]
  Double-click "Start.bat" to launch the tool.
  A browser window will open automatically.
  DO NOT close the command line window.

[System Requirements]
  - Windows 7 / 8 / 8.1 / 10 / 11 (64-bit)
  - Chrome or Edge browser recommended
  - No Python or other software installation needed

[First Time - Activation]
  1. After launch, the interface shows a "Machine Code"
  2. Send the machine code to the administrator
  3. The administrator will return a "License Code"
  4. Paste the license code and click Activate
  5. Activation is permanent on the same computer

[Usage Steps]
  1. Import PDF source file
  2. Import Excel naming table (with filename and page count columns)
  3. Select the corresponding column names
  4. Click "Generate Preview"
  5. Review previews, use +/- buttons to adjust if misaligned
  6. Click the green export button at the bottom

[Features]
  - Search: Type filename to quickly locate files
  - Rotate: Click rotate icon to rotate pages 90 degrees
  - Zoom: Drag the zoom slider to adjust thumbnail size
  - Enlarge: Click thumbnails for full-screen view
  - Offset: Use +/- buttons to adjust page allocation

[Notes]
  - The software runs completely offline
  - No files are uploaded to any server
  - Exported ZIP files are saved to browser's default download folder
