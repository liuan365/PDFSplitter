"""
授权验证模块
- 生成机器码（基于硬件特征）
- 验证授权码（RSA 公钥验证签名）
- 授权持久化（保存到本地文件）
"""
import os
import sys
import json
import uuid
import hashlib
import base64
import platform
import subprocess
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization, hashes

# 公钥将在构建时内嵌
PUBLIC_KEY_PEM = None

def _get_app_dir():
    """获取应用数据目录"""
    if platform.system() == 'Windows':
        app_data = os.environ.get('LOCALAPPDATA', os.path.expanduser('~'))
        d = os.path.join(app_data, 'PDFSplitterPro')
    else:
        d = os.path.join(os.path.expanduser('~'), '.pdf_splitter_pro')
    os.makedirs(d, exist_ok=True)
    return d

def _get_license_file():
    return os.path.join(_get_app_dir(), 'license.json')

def _load_public_key():
    """加载公钥"""
    global PUBLIC_KEY_PEM
    if PUBLIC_KEY_PEM:
        return serialization.load_pem_public_key(PUBLIC_KEY_PEM.encode('utf-8'))
    # 开发模式：从文件加载
    key_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'public_key.pem')
    if os.path.exists(key_path):
        with open(key_path, 'rb') as f:
            return serialization.load_pem_public_key(f.read())
    raise FileNotFoundError("公钥未找到")

def get_machine_code():
    """
    生成机器码：基于多个硬件特征的哈希
    在不同操作系统上使用不同的采集方式
    """
    identifiers = []
    
    # MAC 地址
    mac = uuid.getnode()
    identifiers.append(f"MAC:{mac}")
    
    # 操作系统信息
    identifiers.append(f"OS:{platform.system()}-{platform.machine()}")
    
    # 尝试获取硬盘序列号（Windows）
    if platform.system() == 'Windows':
        try:
            result = subprocess.run(
                ['wmic', 'diskdrive', 'get', 'serialnumber'],
                capture_output=True, text=True, timeout=5,
                creationflags=0x08000000  # CREATE_NO_WINDOW
            )
            serial = result.stdout.strip().split('\n')
            if len(serial) > 1:
                identifiers.append(f"DISK:{serial[1].strip()}")
        except Exception:
            pass
        
        # 尝试获取主板序列号
        try:
            result = subprocess.run(
                ['wmic', 'baseboard', 'get', 'serialnumber'],
                capture_output=True, text=True, timeout=5,
                creationflags=0x08000000
            )
            serial = result.stdout.strip().split('\n')
            if len(serial) > 1:
                identifiers.append(f"MB:{serial[1].strip()}")
        except Exception:
            pass
    else:
        # Linux/Mac: 使用 machine-id
        for path in ['/etc/machine-id', '/var/lib/dbus/machine-id']:
            if os.path.exists(path):
                with open(path, 'r') as f:
                    identifiers.append(f"MID:{f.read().strip()}")
                break
    
    # 组合所有标识符并哈希
    combined = '|'.join(sorted(identifiers))
    hash_val = hashlib.sha256(combined.encode('utf-8')).hexdigest()
    
    # 取前16位，转大写，每4位加横杠，便于阅读
    short_code = hash_val[:16].upper()
    machine_code = '-'.join([short_code[i:i+4] for i in range(0, 16, 4)])
    
    return machine_code

def verify_license(machine_code, license_code):
    """用公钥验证授权码"""
    try:
        public_key = _load_public_key()
        signature = base64.b64decode(license_code)
        public_key.verify(
            signature,
            machine_code.encode('utf-8'),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return True
    except Exception:
        return False

def save_license(machine_code, license_code):
    """保存授权信息到本地"""
    data = {
        'machine_code': machine_code,
        'license_code': license_code,
    }
    license_file = _get_license_file()
    with open(license_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)

def load_saved_license():
    """加载已保存的授权信息"""
    license_file = _get_license_file()
    if not os.path.exists(license_file):
        return None, None
    try:
        with open(license_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get('machine_code'), data.get('license_code')
    except Exception:
        return None, None

def is_licensed():
    """检查当前机器是否已授权"""
    current_machine = get_machine_code()
    saved_machine, saved_license = load_saved_license()
    
    if saved_machine and saved_license:
        # 验证保存的授权码是否对当前机器有效
        if saved_machine == current_machine and verify_license(current_machine, saved_license):
            return True
    return False

def activate(license_code):
    """
    激活软件
    返回: (success: bool, message: str)
    """
    machine_code = get_machine_code()
    license_code = license_code.strip()
    
    if verify_license(machine_code, license_code):
        save_license(machine_code, license_code)
        return True, "激活成功！"
    else:
        return False, "授权码无效，请检查是否正确输入。"
