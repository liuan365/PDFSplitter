"""
PDF 智能拆分与重命名工具 - 后端服务
完全本地运行，仅监听 127.0.0.1
"""
import os
import sys
import io
import json
import zipfile
import tempfile
import datetime
from flask import Flask, request, jsonify, send_file, send_from_directory
from pypdf import PdfReader, PdfWriter
from license_manager import is_licensed, activate, get_machine_code

# 确定资源目录
if getattr(sys, 'frozen', False):
    # PyInstaller / Nuitka 打包后
    BASE_DIR = os.path.dirname(sys.executable)
    STATIC_DIR = os.path.join(BASE_DIR, 'static')
    TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    STATIC_DIR = os.path.join(BASE_DIR, 'static')
    TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')

app = Flask(__name__,
            static_folder=STATIC_DIR,
            template_folder=TEMPLATES_DIR)

app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB 上限

# 临时存储上传的 PDF 数据
pdf_storage = {}

# ============================================================
# 授权相关 API
# ============================================================

@app.route('/api/license/status', methods=['GET'])
def license_status():
    """检查授权状态"""
    return jsonify({
        'licensed': is_licensed(),
        'machine_code': get_machine_code()
    })

@app.route('/api/license/activate', methods=['POST'])
def license_activate():
    """激活授权"""
    data = request.get_json()
    if not data or 'license_code' not in data:
        return jsonify({'success': False, 'message': '请提供授权码'}), 400
    
    success, message = activate(data['license_code'])
    return jsonify({'success': success, 'message': message})

# ============================================================
# PDF 相关 API
# ============================================================

@app.route('/api/upload/pdf', methods=['POST'])
def upload_pdf():
    """上传 PDF 文件"""
    if not is_licensed():
        return jsonify({'error': '软件未授权'}), 403
    
    if 'file' not in request.files:
        return jsonify({'error': '未选择文件'}), 400
    
    f = request.files['file']
    if not f.filename.lower().endswith('.pdf'):
        return jsonify({'error': '请上传 PDF 文件'}), 400
    
    pdf_bytes = f.read()
    try:
        reader = PdfReader(io.BytesIO(pdf_bytes))
        total_pages = len(reader.pages)
    except Exception as e:
        return jsonify({'error': f'PDF 文件读取失败: {str(e)}'}), 400
    
    # 存储 PDF 数据
    pdf_storage['current'] = pdf_bytes
    pdf_storage['filename'] = f.filename
    pdf_storage['total_pages'] = total_pages
    
    return jsonify({
        'filename': f.filename,
        'total_pages': total_pages,
        'size': len(pdf_bytes)
    })

@app.route('/api/upload/excel', methods=['POST'])
def upload_excel():
    """上传 Excel 文件，解析内容返回"""
    if not is_licensed():
        return jsonify({'error': '软件未授权'}), 403
    
    if 'file' not in request.files:
        return jsonify({'error': '未选择文件'}), 400
    
    f = request.files['file']
    fname = f.filename.lower()
    if not (fname.endswith('.xlsx') or fname.endswith('.xls') or fname.endswith('.csv')):
        return jsonify({'error': '请上传 Excel 或 CSV 文件'}), 400
    
    file_bytes = f.read()
    
    try:
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(file_bytes), read_only=True)
        ws = wb.active
        
        rows = []
        headers = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i == 0:
                headers = [str(c) if c is not None else f'列{j+1}' for j, c in enumerate(row)]
            else:
                row_data = {}
                for j, c in enumerate(row):
                    if j < len(headers):
                        row_data[headers[j]] = str(c) if c is not None else ''
                if any(v.strip() for v in row_data.values()):
                    rows.append(row_data)
        wb.close()
    except Exception as e:
        return jsonify({'error': f'Excel 文件解析失败: {str(e)}'}), 400
    
    return jsonify({
        'filename': f.filename,
        'headers': headers,
        'rows': rows,
        'total_rows': len(rows)
    })

@app.route('/api/preview/page/<int:page_num>', methods=['GET'])
def preview_page(page_num):
    """渲染指定页面为 PNG 图片用于预览"""
    if not is_licensed():
        return jsonify({'error': '软件未授权'}), 403
    
    if 'current' not in pdf_storage:
        return jsonify({'error': '未上传 PDF'}), 400
    
    total = pdf_storage['total_pages']
    if page_num < 1 or page_num > total:
        return jsonify({'error': f'页码超出范围 (1-{total})'}), 400
    
    # 使用 pdf2image 将 PDF 页面转为图片
    try:
        from pdf2image import convert_from_bytes
        images = convert_from_bytes(
            pdf_storage['current'],
            first_page=page_num,
            last_page=page_num,
            dpi=120,
            fmt='png'
        )
        if images:
            img_io = io.BytesIO()
            images[0].save(img_io, 'PNG', optimize=True)
            img_io.seek(0)
            return send_file(img_io, mimetype='image/png')
    except ImportError:
        # pdf2image 不可用，返回占位符
        pass
    except Exception as e:
        return jsonify({'error': f'预览生成失败: {str(e)}'}), 500
    
    return jsonify({'error': '预览功能不可用'}), 500

@app.route('/api/split', methods=['POST'])
def split_pdf():
    """执行 PDF 拆分并返回 ZIP"""
    if not is_licensed():
        return jsonify({'error': '软件未授权'}), 403
    
    if 'current' not in pdf_storage:
        return jsonify({'error': '未上传 PDF'}), 400
    
    data = request.get_json()
    if not data or 'tasks' not in data:
        return jsonify({'error': '缺少拆分任务数据'}), 400
    
    tasks = data['tasks']
    rotations = data.get('rotations', {})
    
    try:
        reader = PdfReader(io.BytesIO(pdf_storage['current']))
        total = len(reader.pages)
        
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
            for task in tasks:
                name = task['name']
                start = task['start']  # 1-based
                end = task['end']      # 1-based
                
                if start > total:
                    continue
                
                writer = PdfWriter()
                
                # 设置完整元数据
                for k in range(start, min(end, total) + 1):
                    page = reader.pages[k - 1]
                    writer.add_page(page)
                    
                    # 应用旋转
                    rot_key = str(k)
                    user_rot = rotations.get(rot_key, 0)
                    if user_rot != 0:
                        # pypdf 的旋转是累加的
                        writer.pages[-1].rotate(user_rot)
                
                # 设置元数据
                writer.add_metadata({
                    '/Title': name,
                    '/Author': 'PDF智能拆分工具',
                    '/Creator': 'PDF智能拆分与重命名工具 v1.0',
                    '/Producer': 'pypdf (https://pypdf.readthedocs.io/)',
                    '/Subject': '由PDF智能拆分工具生成',
                    '/CreationDate': datetime.datetime.now().strftime("D:%Y%m%d%H%M%S"),
                    '/ModDate': datetime.datetime.now().strftime("D:%Y%m%d%H%M%S"),
                })
                
                # 写入 ZIP
                safe_name = name.replace('\\', '_').replace('/', '_')
                for ch in ':*?"<>|':
                    safe_name = safe_name.replace(ch, '_')
                
                pdf_bytes_io = io.BytesIO()
                writer.write(pdf_bytes_io)
                zf.writestr(f'{safe_name}.pdf', pdf_bytes_io.getvalue())
        
        zip_buffer.seek(0)
        today = datetime.datetime.now().strftime('%Y-%m-%d')
        return send_file(
            zip_buffer,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f'PDF拆分结果_{today}.zip'
        )
    except Exception as e:
        return jsonify({'error': f'拆分失败: {str(e)}'}), 500

@app.route('/api/pdf/info', methods=['GET'])
def pdf_info():
    """获取当前 PDF 信息"""
    if 'current' not in pdf_storage:
        return jsonify({'uploaded': False})
    return jsonify({
        'uploaded': True,
        'filename': pdf_storage.get('filename', ''),
        'total_pages': pdf_storage.get('total_pages', 0)
    })

# ============================================================
# 静态文件服务
# ============================================================

@app.route('/')
def index():
    return send_from_directory(TEMPLATES_DIR, 'index.html')

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory(STATIC_DIR, filename)

def get_free_port():
    """获取一个可用端口"""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def run_server(port=None):
    """启动服务"""
    if port is None:
        port = 18088
    print(f"\n{'='*50}")
    print(f"  PDF 智能拆分与重命名工具 v1.0")
    print(f"  本地地址: http://127.0.0.1:{port}")
    print(f"  按 Ctrl+C 退出")
    print(f"{'='*50}\n")
    app.run(host='127.0.0.1', port=port, debug=False, threaded=True)

if __name__ == '__main__':
    run_server()
