"""
PDF 智能拆分与重命名工具 - 主启动入口
适配嵌入式 Python 环境
"""
import os
import sys
import socket
import threading
import webbrowser
import time

def get_base_dir():
    """获取 app 目录"""
    return os.path.dirname(os.path.abspath(__file__))

def is_port_available(port):
    """检查端口是否可用"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('127.0.0.1', port))
            return True
        except OSError:
            return False

def find_available_port(start=18088, end=18200):
    """查找可用端口"""
    for port in range(start, end):
        if is_port_available(port):
            return port
    return None

def open_browser(port):
    """延迟打开浏览器"""
    time.sleep(2.0)
    url = f'http://127.0.0.1:{port}'
    print(f"正在打开浏览器: {url}")
    webbrowser.open(url)

def main():
    # 切换工作目录到 app 所在位置
    base_dir = get_base_dir()
    os.chdir(base_dir)
    
    # 确保 app 目录在 sys.path 中
    if base_dir not in sys.path:
        sys.path.insert(0, base_dir)
    
    # 查找可用端口
    port = find_available_port()
    if port is None:
        print("错误: 无法找到可用端口 (18088-18200)")
        input("按回车键退出...")
        sys.exit(1)
    
    # 启动浏览器（在后台线程中延迟打开）
    browser_thread = threading.Thread(target=open_browser, args=(port,), daemon=True)
    browser_thread.start()
    
    # 启动 Flask 服务
    from app import run_server
    try:
        run_server(port=port)
    except KeyboardInterrupt:
        print("\n服务已停止。")

if __name__ == '__main__':
    main()
